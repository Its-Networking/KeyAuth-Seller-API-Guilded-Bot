﻿namespace Guilded_KeyAuth_Seller_Bot.Misc
{
    internal class JsonView
    {
    }
}